"""
AGENTE 1 — PESQUISADOR
Busca notícias jurídicas recentes e tendências de busca para gerar pautas.
Usa o OmniRoute (auto/best-fast) para ser rápido e barato.
"""
import json, datetime, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from config import OMNI_BASE, MODELOS, SOBRE_O_SITE
import urllib.request
import time
import urllib.error

def _omni_chat(prompt: str, model: str | None = None) -> str:
    """Faz a chamada ao OmniRoute com sistema anti-bloqueio (Retry/Backoff para Erro 429)."""
    model = model or MODELOS[os.path.basename(__file__).split('_')[1].split('.')[0]]
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    
    tentativas = 5
    espera = 10  # segundos
    
    for i in range(tentativas):
        try:
            req = urllib.request.Request(
                f"{OMNI_BASE}/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f"    ⏳ [Limite de velocidade atingido] Aguardando {espera}s para tentar de novo...")
                time.sleep(espera)
                espera += 10 # Aumenta a espera
            else:
                raise e
    raise Exception("Falha após várias tentativas de contato com a IA (Erro 429 contínuo).")


TEMAS_BASE = [
    "prisão em flagrante Brasil",
    "habeas corpus novidades",
    "tráfico de drogas STJ STF",
    "medida protetiva Maria da Penha",
    "tornozeleira eletrônica violação",
    "júri popular direito penal",
    "mandado de busca apreensão",
    "preso preventivo soltura",
    "crime eleitoral boca de urna",
    "advogado criminalista BH Minas Gerais",
]




def gerar_pauta(data_ref: datetime.date | None = None) -> list[dict]:
    """
    Gera uma lista de pautas para o dia.
    Retorna: [{"titulo": str, "tema": str, "palavras_chave": list[str], "urgencia": bool}]
    """
    data_ref = data_ref or datetime.date.today()
    temas_str = "\n".join(f"- {t}" for t in TEMAS_BASE)

    prompt = f"""Você é um assistente de pauta jurídica para o site de um advogado criminalista.

CONTEXTO DO SITE:
{SOBRE_O_SITE}

DATA DE HOJE: {data_ref.strftime("%d/%m/%Y")}

TEMAS DISPONÍVEIS:
{temas_str}

TAREFA:
Escolha os 3 temas mais relevantes HOJE (considere notícias recentes, datas comemorativas, campanhas jurídicas).
Para cada tema, sugira:
1. Um título de artigo atraente (máx 65 caracteres, sem clickbait)
2. 5 palavras-chave SEO (long tail, como "o que fazer se fui preso")
3. Se é urgente (artigo curto e direto ao ponto) ou explicativo (mais completo)

Responda SOMENTE em JSON válido, sem markdown:
[
  {{"titulo": "...", "tema": "...", "palavras_chave": ["...", "..."], "urgente": false}},
  ...
]"""

    resposta = _omni_chat(prompt)
    # Remove possível markdown code block
    resposta = resposta.strip()
    if resposta.startswith("```"):
        resposta = resposta.split("```")[1]
        if resposta.startswith("json"):
            resposta = resposta[4:]
    return json.loads(resposta.strip())


def pesquisar_conteudo(pauta: dict) -> str:
    """
    Para uma pauta, pesquisa e estrutura o conteúdo do artigo.
    Retorna um briefing completo para o Redator.
    """
    prompt = f"""Você é um pesquisador jurídico especializado em direito criminal brasileiro.

CONTEXTO DO SITE:
{SOBRE_O_SITE}

PAUTA:
Título: {pauta['titulo']}
Tema: {pauta['tema']}
Palavras-chave: {', '.join(pauta['palavras_chave'])}
Urgente: {pauta['urgente']}

TAREFA:
Crie um briefing detalhado para o redator, incluindo:
1. GANCHO: por que esse tema é relevante AGORA (notícia, mudança na lei, data comemorativa)
2. PONTOS PRINCIPAIS: 5-7 informações jurídicas precisas e atuais
3. CASOS PRÁTICOS: 2-3 situações reais que o leitor pode estar vivendo
4. JURISPRUDÊNCIA: cite STJ/STF quando relevante (de forma simplificada)
5. CHAMADA PARA AÇÃO: o que o leitor deve fazer agora (ligar para o Dr. Lucas)

Seja preciso juridicamente. Use linguagem clara para leigos.
NÃO invente leis ou números de súmula — se não tiver certeza, diga "consulte um advogado"."""

    return _omni_chat(prompt)


if __name__ == "__main__":
    print("🔍 Gerando pauta do dia...")
    pautas = gerar_pauta()
    print(f"✅ {len(pautas)} pautas geradas:")
    for p in pautas:
        print(f"  → {p['titulo']} ({'urgente' if p['urgente'] else 'explicativo'})")

    print("\n📋 Pesquisando conteúdo da primeira pauta...")
    briefing = pesquisar_conteudo(pautas[0])
    print(briefing[:500] + "...")

    # Salva saída para o próximo agente
    saida = {"data": str(datetime.date.today()), "pautas": pautas, "briefings": [briefing]}
    with open(os.path.join(os.path.dirname(__file__), "output_pesquisador.json"), "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)
    print("\n💾 Salvo em output_pesquisador.json")
