import re
import os

ARQUIVO = r"C:\Users\adm\Desktop\lucassemim.adv.br\agentes\motor_retroalimentacao.py"
ARQUIVO_REDATOR = r"C:\Users\adm\Desktop\lucassemim.adv.br\agentes\agente_redator.py"

NOVO_TEMPLATE = '''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{titulo} | Dr. Lucas Semim OAB/MG 222.539</title>
    <meta name="description" content="{meta_description}">
    <link rel="canonical" href="https://lucassemim.adv.br/{pasta}/{slug}.html" />
    <link rel="icon" href="/img/Favicon-lucassemim.png" type="image/png">
    {schema}
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Teko:wght@300;400;500;600&family=Fira+Code:wght@400;500&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --bg-zero:#000000; --bg-deep:#040404; --bg-card:#080808; --ouro:#d4af37; --ouro-vivo:#f1c40f; --ouro-dim:rgba(212, 175, 55, 0.12); --ouro-border:rgba(212, 175, 55, 0.25); --alerta:#cc0000; --font-display:'Playfair Display', serif; --font-teko:'Teko', sans-serif; --font-body:'Lato', sans-serif; }
        body { background-color: var(--bg-zero); color: #f0ede8; font-family: var(--font-body); padding-top: 110px; }
        h1, h2, h3 { font-family: var(--font-display); font-weight: 700; }
        .faixa-custodia-urgente { background: var(--alerta); padding: 9px 0; position: fixed; top: 0; left: 0; width: 100%; z-index: 10000; text-align:center;}
        .faixa-txt { font-family: 'Fira Code', monospace; font-size: 0.75rem; color: #fff; letter-spacing: 1.5px; text-transform: uppercase; }
        .hero-title { font-family: var(--font-teko); font-size: clamp(3rem, 6vw, 5rem); color: #fff; text-transform: uppercase; line-height: 0.9; margin: 30px 0; }
        .ouro-line { background: linear-gradient(90deg, var(--ouro), var(--ouro-vivo)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .artigo-conteudo { max-width: 900px; margin: 0 auto; padding: 40px 20px; font-size: 1.15rem; line-height: 1.8; color:#d8d4c9; }
        .artigo-conteudo h2 { color: var(--ouro-vivo); margin-top: 40px; }
        .btn-acionar { display: inline-flex; align-items: center; gap: 12px; background: linear-gradient(135deg, #cc0000, #8b0000); color: #fff; font-family: var(--font-teko); font-size: 1.5rem; letter-spacing: 1.5px; padding: 16px 32px; border-radius: 8px; text-decoration:none;}
        #header-master-injecao { position: fixed; top: 38px; width: 100%; z-index: 9999;}
    </style>
</head>
<body>
    <div class="faixa-custodia-urgente"><span class="faixa-txt">PLANTÃO 24H CRIMINAL - LIGUE AGORA: (31) 98394-4973</span></div>
    <div id="header-master-injecao"></div>

    <section class="container" style="margin-top:40px; text-align:center;">
        <h1 class="hero-title">{titulo}</h1>
        <p style="color:#888; font-style:italic;">Por Dr. Lucas Semim</p>
    </section>

    <main class="artigo-conteudo">
        {conteudo_html}
        
        <div style="margin-top:60px; text-align:center;">
            <a href="https://wa.me/5531983944973?text=Ol%C3%A1%2C%20Dr.%20Lucas.%20Preciso%20de%20ajuda%20urgente." class="btn-acionar">
                <i class="fab fa-whatsapp"></i> FALAR COM DR. LUCAS AGORA
            </a>
        </div>
    </main>

    <div id="footer-master-injecao"></div>
    <script src="/js/header-elite.js?v={versao}"></script>
</body>
</html>'''

def replace_in_file(path, regex_padrao):
    if not os.path.exists(path): return
    with open(path, 'r', encoding='utf-8') as f: text = f.read()
    match = re.search(regex_padrao, text, re.DOTALL)
    if match:
        text = text[:match.start(1)] + NOVO_TEMPLATE + text[match.end(1):]
        with open(path, 'w', encoding='utf-8') as f: f.write(text)
        print(f"Template atualizado em: {path}")

replace_in_file(ARQUIVO, r'TEMPLATE_HTML\s*=\s*(?:"""|\'\'\')(.*?)(?:"""|\'\'\')')
replace_in_file(ARQUIVO_REDATOR, r'TEMPLATE_ARTIGO\s*=\s*(?:"""|\'\'\')(.*?)(?:"""|\'\'\')')
