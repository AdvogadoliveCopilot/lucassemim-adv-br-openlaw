# 🤖 Agentes — lucassemim.adv.br

Pipeline de IA que atualiza o site automaticamente todo dia.

## Arquitetura

```
OmniRoute (localhost:20128)
        │
        ├── AGENTE 1: PESQUISADOR  (auto/best-fast)
        │   └── Gera pautas e pesquisa conteúdo jurídico
        │
        ├── AGENTE 2: REDATOR      (auto/pro-chat)
        │   └── Escreve artigo completo em HTML no padrão do site
        │
        ├── AGENTE 3: SEO          (auto/smart)
        │   └── Valida e otimiza meta tags, schema, links internos
        │
        ├── AGENTE 4: PUBLICADOR   (auto/coding)
        │   └── Salva HTML, roda bump-cache.py, envia por FTP
        │
        └── AGENTE 5: MONITOR      (auto/best-fast)
            └── Verifica disponibilidade e URLs de segurança
```

## Uso rápido

```bash
# Testar conexões (sem publicar nada)
python pipeline.py --testar

# Rodar pipeline uma vez
python pipeline.py

# Só monitorar o site
python pipeline.py --monitor

# Agendar execução diária no Windows (faz uma vez só)
python pipeline.py --agendar
```

## Arquivos

| Arquivo | Papel |
|---------|-------|
| `config.py` | ⚙️ **Edite aqui**: credenciais FTP, modelos, horários |
| `pipeline.py` | 🎛️ Orquestrador principal |
| `agente_pesquisador.py` | 🔍 Gera pautas e pesquisa |
| `agente_redator.py` | ✍️ Redige artigos em HTML |
| `agente_seo.py` | 📈 Otimiza SEO |
| `agente_publicador.py` | 📤 Publica no servidor |
| `agente_monitor.py` | 👁️ Monitora disponibilidade |

## Logs

- `log_pipeline.jsonl` — histórico de execuções do pipeline
- `log_publicacoes.jsonl` — histórico de artigos publicados
- `log_monitor.jsonl` — histórico de monitoramento
- `output_pesquisador.json` — saída do último ciclo (pesquisa)
- `output_redator.json` — saída do último ciclo (HTML)
- `output_seo.json` — saída do último ciclo (SEO)

## Modelos disponíveis no OmniRoute

| Modelo | Uso recomendado |
|--------|----------------|
| `auto/best-fast` | Monitor, pesquisa rápida |
| `auto/pro-chat` | Redação de artigos |
| `auto/smart` | SEO, uso geral |
| `auto/coding` | Publicação, scripts |
| `tllm/gemini_3_pro` | Gratuito, boa qualidade |
| `gweb/gemini-3.5-flash` | Gratuito, muito rápido |

Altere os modelos em `config.py` → `MODELOS`.

## Agendamento

Após rodar `python pipeline.py --agendar`, duas tarefas aparecem no
Agendador de Tarefas do Windows (`taskschd.msc`):

- **LucasSemim_Pipeline** — 03:00 todo dia (publica artigos)
- **LucasSemim_Monitor** — 06:00 todo dia (checa saúde do site)

## ⚠️ Importante

- O OmniRoute precisa estar rodando (`omniroute` no terminal)
- O PC precisa estar ligado nos horários agendados
- Os artigos são salvos em `/artigos/` no site — a pasta precisa existir no servidor
