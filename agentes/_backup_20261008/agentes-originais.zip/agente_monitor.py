"""
AGENTE 5 — MONITOR
Checa se o site está online e coleta métricas básicas.
Roda de forma independente — não depende dos outros agentes.
"""
import json, datetime, sys, os, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(__file__))
from config import OMNI_BASE, MODELOS

LOG_FILE = os.path.join(os.path.dirname(__file__), "log_monitor.jsonl")

URLS_CHECAR = [
    "https://lucassemim.adv.br/",
    "https://lucassemim.adv.br/artigos.html",
    "https://lucassemim.adv.br/emergencia.html",
    "https://civel.lucassemim.adv.br/",
    "https://lucassemim.adv.br/sw.js",          # service worker
]

URLS_DEVEM_DAR_403 = [
    "https://civel.lucassemim.adv.br/Advogado%20Live.json",
    "https://lucassemim.adv.br/.git/",
    "https://lucassemim.adv.br/.env",
]


def _checar_url(url: str, esperado_403: bool = False) -> dict:
    inicio = time.monotonic()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "LucasMonitor/1.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            status = r.status
            tamanho = len(r.read())
    except urllib.error.HTTPError as e:
        status = e.code
        tamanho = 0
    except Exception as e:
        status = 0
        tamanho = 0

    ms = round((time.monotonic() - inicio) * 1000)
    ok = (status == 403) if esperado_403 else (200 <= status < 400)

    return {
        "url": url,
        "status": status,
        "ok": ok,
        "ms": ms,
        "bytes": tamanho,
        "esperado_403": esperado_403,
    }


def _omni_chat(prompt: str) -> str:
    payload = json.dumps({
        "model": MODELOS["monitor"],
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    req = urllib.request.Request(
        f"{OMNI_BASE}/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read())
    return data["choices"][0]["message"]["content"]


def monitorar() -> dict:
    """Roda todas as verificações e retorna relatório."""
    ts = datetime.datetime.now().isoformat()
    resultados = []

    print("🔍 Verificando URLs do site...")
    for url in URLS_CHECAR:
        r = _checar_url(url)
        status_emoji = "✅" if r["ok"] else "❌"
        print(f"  {status_emoji} {r['status']} {r['ms']}ms — {url}")
        resultados.append(r)

    print("\n🔒 Verificando URLs que devem dar 403...")
    for url in URLS_DEVEM_DAR_403:
        r = _checar_url(url, esperado_403=True)
        status_emoji = "✅" if r["ok"] else "🚨"
        print(f"  {status_emoji} {r['status']} — {url}")
        resultados.append(r)

    falhas = [r for r in resultados if not r["ok"]]
    urgente = any(r for r in falhas if not r["esperado_403"])

    # Gera resumo com IA se houver problemas
    resumo_ia = None
    if falhas:
        prompt = f"""Você é um assistente de monitoramento de site jurídico.

RESULTADOS DO MONITORAMENTO ({ts}):
{json.dumps(resultados, ensure_ascii=False, indent=2)}

FALHAS DETECTADAS:
{json.dumps(falhas, ensure_ascii=False, indent=2)}

Escreva um relatório de 3-5 linhas para o webmaster, explicando:
1. O que está com problema
2. A causa mais provável
3. O que fazer agora

Seja direto e técnico."""
        try:
            resumo_ia = _omni_chat(prompt)
        except Exception as e:
            resumo_ia = f"(IA indisponível: {e})"

    relatorio = {
        "ts": ts,
        "total": len(resultados),
        "ok": len(resultados) - len(falhas),
        "falhas": len(falhas),
        "urgente": urgente,
        "resultados": resultados,
        "resumo_ia": resumo_ia,
    }

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(relatorio, ensure_ascii=False) + "\n")

    return relatorio


if __name__ == "__main__":
    rel = monitorar()
    print(f"\n{'🚨 ATENÇÃO — há falhas!' if rel['urgente'] else '✅ Tudo OK!'}")
    print(f"   {rel['ok']}/{rel['total']} URLs saudáveis")
    if rel.get("resumo_ia"):
        print(f"\n📋 Análise IA:\n{rel['resumo_ia']}")
