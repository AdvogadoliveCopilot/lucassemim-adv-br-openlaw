"""
AGENTE 3 — SEO
Valida e aprimora meta tags, Schema markup e internal links dos artigos.
Usa auto/smart para balancear velocidade e qualidade.
"""
import json, sys, os, re
sys.path.insert(0, os.path.dirname(__file__))
from config import OMNI_BASE, MODELOS
import urllib.request
import time
import urllib.error

def _omni_chat(prompt: str, model: str | None = None) -> str:
    """Faz a chamada ao OmniRoute com sistema anti-bloqueio (Retry/Backoff para Erro 429)."""
    model = model or MODELOS[os.path.basename(__file__).split('_')[1].split('.')[0]]
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    
    tentativas = 5
    espera = 10  # segundos
    
    for i in range(tentativas):
        try:
            req = urllib.request.Request(
                f"{OMNI_BASE}/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f"    ⏳ [Limite de velocidade atingido] Aguardando {espera}s para tentar de novo...")
                time.sleep(espera)
                espera += 10 # Aumenta a espera
            else:
                raise e
    raise Exception("Falha após várias tentativas de contato com a IA (Erro 429 contínuo).")





def _verificar_seo_basico(html: str, slug: str) -> list[str]:
    """Verificações automáticas sem IA."""
    problemas = []
    if not re.search(r'<title>[^<]{10,65}</title>', html):
        problemas.append("title ausente ou fora do tamanho ideal (10-65 chars)")
    if not re.search(r'<meta name="description" content="[^"]{50,155}"', html):
        problemas.append("meta description ausente ou fora do tamanho ideal (50-155 chars)")
    if not re.search(r'<h1[^>]*>[^<]+</h1>', html):
        problemas.append("H1 ausente")
    if not re.search(r'<h2[^>]*>[^<]+</h2>', html):
        problemas.append("Nenhum H2 encontrado")
    if not re.search(r'type="application/ld\+json"', html):
        problemas.append("Schema JSON-LD ausente")
    if not re.search(r'rel="canonical"', html):
        problemas.append("Link canonical ausente")
    palavra_chave = slug.replace("-", " ")
    if palavra_chave not in html.lower():
        problemas.append(f"Slug/palavra-chave '{palavra_chave}' não encontrado no HTML")
    return problemas


def otimizar_seo(artigo: dict) -> dict:
    """
    Recebe artigo do Redator, retorna versão otimizada.
    artigo: {"html": str, "titulo": str, "slug": str, "meta_description": str, "tags": list}
    """
    problemas = _verificar_seo_basico(artigo["html"], artigo["slug"])

    prompt = f"""Você é um especialista em SEO para sites jurídicos brasileiros.

ARTIGO:
Título: {artigo['titulo']}
Slug: {artigo['slug']}
Meta description: {artigo['meta_description']}
Tags: {', '.join(artigo['tags'])}

PROBLEMAS DETECTADOS AUTOMATICAMENTE:
{chr(10).join('- ' + p for p in problemas) if problemas else '- Nenhum problema grave detectado'}

HTML DO ARTIGO (primeiros 3000 chars):
{artigo['html'][:3000]}

TAREFA:
1. Avalie o SEO do artigo (nota 0-100)
2. Liste até 5 melhorias prioritárias
3. Se a meta description puder ser melhorada, sugira uma nova (máx 155 chars)
4. Sugira 2-3 links internos que poderiam ser inseridos no texto
   (use URLs reais do site: /o-que-fazer-agora/, /defesa-criminal/, /artigos.html, etc.)
5. Se houver palavras-chave importantes faltando no texto, cite-as

Responda em JSON:
{{
  "nota_seo": 85,
  "melhorias": ["...", "..."],
  "meta_description_sugerida": "...",
  "links_internos": [{{"texto": "...", "url": "/...", "posicao": "início|meio|fim"}}],
  "palavras_chave_faltando": ["..."]
}}"""

    resposta = _omni_chat(prompt)
    resposta = resposta.strip()
    if resposta.startswith("```"):
        resposta = resposta.split("```")[1]
        if resposta.startswith("json"):
            resposta = resposta[4:]

    relatorio = json.loads(resposta.strip())

    # Aplica meta description melhorada se sugerida
    html = artigo["html"]
    if relatorio.get("meta_description_sugerida"):
        nova_desc = relatorio["meta_description_sugerida"]
        html = re.sub(
            r'<meta name="description" content="[^"]*"',
            f'<meta name="description" content="{nova_desc}"',
            html,
        )

    artigo_otimizado = {**artigo, "html": html, "relatorio_seo": relatorio}
    return artigo_otimizado


if __name__ == "__main__":
    entrada = os.path.join(os.path.dirname(__file__), "output_redator.json")
    if not os.path.exists(entrada):
        print("❌ Execute o agente_redator.py primeiro.")
        sys.exit(1)

    with open(entrada, encoding="utf-8") as f:
        dados = json.load(f)

    artigos_otimizados = []
    for artigo in dados["artigos"]:
        print(f"🔍 Otimizando SEO: {artigo['titulo']}...")
        artigo_ok = otimizar_seo(artigo)
        nota = artigo_ok["relatorio_seo"].get("nota_seo", "?")
        print(f"  ✅ Nota SEO: {nota}/100")
        artigos_otimizados.append(artigo_ok)

    saida = {**dados, "artigos": artigos_otimizados}
    with open(os.path.join(os.path.dirname(__file__), "output_seo.json"), "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)
    print("\n💾 Salvo em output_seo.json")
