"""
AGENTE 4 — PUBLICADOR
Salva o HTML no site local, roda bump-cache.py e envia por FTP.
Usa ftplib (stdlib do Python) — sem dependências externas.
"""
import json, sys, os, ftplib, datetime, subprocess
sys.path.insert(0, os.path.dirname(__file__))
from config import (FTP_HOST, FTP_PORT, FTP_USER, FTP_PASS,
                    FTP_ROOT, SITE_DIR)


LOG_FILE = os.path.join(os.path.dirname(__file__), "log_publicacoes.jsonl")


def _log(evento: dict):
    evento["ts"] = datetime.datetime.now().isoformat()
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(evento, ensure_ascii=False) + "\n")
    print(f"  [{evento['ts'][:19]}] {evento.get('msg', evento)}")


def salvar_local(artigo: dict) -> str:
    """Salva o HTML na pasta de artigos do site local."""
    # Artigos ficam em /artigos/ ou direto na raiz — ajuste conforme o site
    pasta_artigos = os.path.join(SITE_DIR, "artigos")
    os.makedirs(pasta_artigos, exist_ok=True)
    caminho = os.path.join(pasta_artigos, artigo["nome_arquivo"])
    with open(caminho, "w", encoding="utf-8") as f:
        f.write(artigo["html"])
    _log({"msg": f"Salvo localmente: {caminho}", "arquivo": artigo["nome_arquivo"]})
    return caminho


def bump_cache(versao: str | None = None):
    """Roda o bump-cache.py para atualizar os ?v= nas páginas."""
    versao = versao or datetime.date.today().strftime("%Y%m%d")
    script = os.path.join(SITE_DIR, "civel", "Claude outputs", "release-20261004", "bump-cache.py")
    if not os.path.exists(script):
        _log({"msg": "⚠️  bump-cache.py não encontrado, pulando", "script": script})
        return
    resultado = subprocess.run(
        ["python", script, SITE_DIR, versao],
        capture_output=True, text=True, timeout=120
    )
    if resultado.returncode == 0:
        _log({"msg": f"bump-cache.py ok (v={versao})", "stdout": resultado.stdout[:200]})
    else:
        _log({"msg": "⚠️  bump-cache.py com erro", "stderr": resultado.stderr[:300]})


def enviar_ftp(caminho_local: str, caminho_remoto: str):
    """Envia um arquivo por FTP."""
    _log({"msg": f"FTP → {caminho_remoto}"})
    with ftplib.FTP() as ftp:
        ftp.connect(FTP_HOST, FTP_PORT, timeout=30)
        ftp.login(FTP_USER, FTP_PASS)
        ftp.set_pasv(True)

        # Garante que o diretório remoto existe
        partes = caminho_remoto.split("/")
        for i in range(2, len(partes)):
            d = "/".join(partes[:i])
            try:
                ftp.mkd(d)
            except ftplib.error_perm:
                pass  # já existe

        with open(caminho_local, "rb") as f:
            ftp.storbinary(f"STOR {caminho_remoto}", f)

    _log({"msg": f"✅ Enviado: {caminho_remoto}"})


def publicar(artigos: list[dict]):
    """Pipeline completo: salvar → bump-cache → FTP."""
    hoje = datetime.date.today()
    versao = hoje.strftime("%Y%m%d")

    for artigo in artigos:
        print(f"\n📤 Publicando: {artigo['titulo']}")

        # 1. Salva localmente
        caminho_local = salvar_local(artigo)

        # 2. Bump cache (atualiza ?v= nas páginas existentes)
        bump_cache(versao)

        # 3. Envia por FTP
        nome = artigo["nome_arquivo"]
        caminho_remoto = f"{FTP_ROOT}/artigos/{nome}"
        enviar_ftp(caminho_local, caminho_remoto)

        _log({
            "tipo": "publicacao",
            "artigo": artigo["titulo"],
            "slug": artigo["slug"],
            "url": f"https://lucassemim.adv.br/artigos/{nome}",
            "nota_seo": artigo.get("relatorio_seo", {}).get("nota_seo", "?"),
        })

    print(f"\n✅ {len(artigos)} artigo(s) publicado(s).")


if __name__ == "__main__":
    entrada = os.path.join(os.path.dirname(__file__), "output_seo.json")
    if not os.path.exists(entrada):
        print("❌ Execute o agente_seo.py primeiro.")
        sys.exit(1)

    with open(entrada, encoding="utf-8") as f:
        dados = json.load(f)

    publicar(dados["artigos"])
