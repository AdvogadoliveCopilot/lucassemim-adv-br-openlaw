import os
import re

PASTA = r"C:\Users\adm\Desktop\lucassemim.adv.br\agentes"

NOVO_OMNI_CHAT = '''import time
import urllib.error

def _omni_chat(prompt: str, model: str | None = None) -> str:
    """Faz a chamada ao OmniRoute com sistema anti-bloqueio (Retry/Backoff para Erro 429)."""
    model = model or MODELOS[os.path.basename(__file__).split('_')[1].split('.')[0]]
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    
    tentativas = 5
    espera = 10  # segundos
    
    for i in range(tentativas):
        try:
            req = urllib.request.Request(
                f"{OMNI_BASE}/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f"    ⏳ [Limite de velocidade atingido] Aguardando {espera}s para tentar de novo...")
                time.sleep(espera)
                espera += 10 # Aumenta a espera
            else:
                raise e
    raise Exception("Falha após várias tentativas de contato com a IA (Erro 429 contínuo).")
'''

def atualizar_agente(arquivo):
    caminho = os.path.join(PASTA, arquivo)
    if not os.path.exists(caminho): return
    
    with open(caminho, 'r', encoding='utf-8') as f:
        texto = f.read()
    
    # Remove a função antiga _omni_chat
    texto = re.sub(r'def _omni_chat\(prompt: str, model: str \| None = None\) -> str:.*?return data\["choices"\]\[0\]\["message"\]\["content"\]\n', '', texto, flags=re.DOTALL)
    
    # Injeta a nova com import time logo após os imports
    texto = texto.replace('import urllib.request', 'import urllib.request\n' + NOVO_OMNI_CHAT)
    
    with open(caminho, 'w', encoding='utf-8') as f:
        f.write(texto)
    print(f"Atualizado: {arquivo}")

atualizar_agente("agente_pesquisador.py")
atualizar_agente("agente_redator.py")
atualizar_agente("agente_seo.py")
atualizar_agente("agente_monitor.py")
