# 🛠️ Guia de Configuração: Gemini API no OmniRoute

Este guia detalha o passo a passo para conectar uma chave gratuita do **Google AI Studio (Gemini API)** ao **OmniRoute** local (`http://localhost:20128`), garantindo estabilidade, alta velocidade e evitando bloqueios de cotas (429/503/403).

---

## 📌 Por que configurar a Gemini API?
Atualmente, as rotas comunitárias e gratuitas (como `cc/claude`, `gweb`, `tllm`) enfrentam limites de requisições (429) ou indisponibilidade temporária (503). O Google AI Studio oferece uma **cota gratuita generosa** com alta velocidade e suporte nativo a modelos topo de linha (`gemini-2.0-flash`, `gemini-1.5-pro`).

---

## 🚀 Passo a Passo

### 1. Obter a Chave de API Gratuita no Google AI Studio
1. Acesse: **[https://aistudio.google.com/](https://aistudio.google.com/)**
2. Faça login com sua conta Google.
3. No menu lateral ou superior esquerdo, clique no botão **"Get API key"** (Obter chave de API).
4. Clique em **"Create API key"** (Criar chave de API) em um novo projeto (ou selecione um projeto existente do Google Cloud).
5. Copie a chave gerada (ela começa com `AIzaSy...`). Guarde-a com segurança.

---

### 2. Acessar o Painel do OmniRoute
1. Certifique-se de que o OmniRoute está rodando localmente.
2. Abra seu navegador e acesse a interface web do OmniRoute:
   👉 **[http://localhost:20128/home](http://localhost:20128/home)**
3. No menu lateral, navegue até a seção **Providers** (Provedores).
4. Localize o provedor **Google AI Studio** (ou **Gemini**).

---

### 3. Inserir a Chave e Ativar os Modelos
1. Cole sua chave de API copiada no campo correspondente (**API Key**).
2. Salve as configurações do provedor.
3. Ative os modelos recomendados para a esteira de agentes:
   - `gemini-2.0-flash` — Recomendado para **Pesquisador**, **SEO** e **Monitor** (respostas instantâneas e econômicas).
   - `gemini-1.5-pro` (ou `gemini-2.5-pro` se listado) — Recomendado para o **Redator** (criação de artigos jurídicos com redação elaborada).

---

### 4. Testar a Conexão
Abra o terminal (PowerShell) na raiz do projeto e execute:

```powershell
python agentes/pipeline.py --testar
```

Você deverá ver a confirmação de que o OmniRoute e o FTP estão 100% operacionais:
```text
[TESTE] Testando conexoes...
  ✅ OmniRoute OK — 139+ modelos disponíveis
  ✅ FTP OK — Itens em /public_html listados com sucesso
```

Para validar a geração de texto pelo modelo configurado, execute um teste rápido via PowerShell:
```powershell
Invoke-RestMethod -Uri http://localhost:20128/api/v1/chat/completions -Method POST -Body '{"model":"gemini-2.0-flash","messages":[{"role":"user","content":"ok"}],"stream":false}' -ContentType application/json -TimeoutSec 15
```

---

### 5. Fallback Automático e Modelos Ativos
O arquivo `agentes/config.py` já conta com a função de detecção dinâmica:

```python
MODELO_ATIVO = encontrar_modelo_funcionando()
```

- **Como funciona o Fallback:** A função testa uma lista de modelos prioritários e armazena em cache no arquivo `working_model.txt` por 1 hora.
- **Configuração personalizada:** Quando a chave Gemini estiver ativa, você pode definir diretamente os modelos no dicionário `MODELOS` em `agentes/config.py`:
  ```python
  MODELOS = {
      "pesquisador": "gemini-2.0-flash",   # ultra rápido para busca e síntese
      "redator":     "gemini-1.5-pro",     # raciocínio profundo e redação jurídica
      "seo":         "gemini-2.0-flash",   # meta tags, slugs e schema JSON-LD
      "publicador":  "gemini-2.0-flash",   # scripts de publicação e FTP
      "monitor":     "gemini-2.0-flash",   # diagnósticos de saúde e relatórios
  }
  ```

---

## 🛡️ Monitoramento e Saúde
Para validar a integridade dos serviços do site a qualquer momento, execute:

```powershell
python agentes/agente_monitor_avancado.py
```
O relatório visual será atualizado em `agentes/relatorio_monitor.html`.
