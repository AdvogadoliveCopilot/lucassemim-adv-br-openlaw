"""
PIPELINE PRINCIPAL — lucassemim.adv.br
Orquestra todos os agentes em sequência e agenda execução diária.

Uso:
  python pipeline.py              → roda uma vez agora
  python pipeline.py --agendar   → agenda execução diária via Windows Task Scheduler
  python pipeline.py --monitor   → só roda o monitor
  python pipeline.py --testar    → testa conexão OmniRoute e FTP sem publicar
"""
import sys, os, json, datetime, subprocess, argparse

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


# Adiciona a pasta de agentes ao path
PASTA = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PASTA)

from config import OMNI_BASE, FTP_HOST, FTP_USER, HORA_PUBLICACAO, HORA_MONITOR
import urllib.request, ftplib


# ─── Funções de utilidade ─────────────────────────────────────────────────────

def _testar_omni():
    """Testa se o OmniRoute está respondendo."""
    try:
        req = urllib.request.Request(f"{OMNI_BASE}/models")
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        n = len(data.get("data", []))
        print(f"  ✅ OmniRoute OK — {n} modelos disponíveis")
        return True
    except Exception as e:
        print(f"  ❌ OmniRoute falhou: {e}")
        return False


def _testar_ftp():
    """Testa conexão FTP."""
    from config import FTP_PORT, FTP_PASS, FTP_ROOT
    try:
        with ftplib.FTP() as ftp:
            ftp.connect(FTP_HOST, FTP_PORT, timeout=15)
            ftp.login(FTP_USER, FTP_PASS)
            ftp.set_pasv(True)
            arquivos = ftp.nlst(FTP_ROOT)
            print(f"  ✅ FTP OK — {len(arquivos)} itens em {FTP_ROOT}")
        return True
    except Exception as e:
        print(f"  ❌ FTP falhou: {e}")
        return False


def _rodar_agente(script: str, nome: str) -> bool:
    """Roda um agente como subprocesso e retorna True se OK."""
    caminho = os.path.join(PASTA, script)
    print(f"\n{'='*60}")
    print(f"  🤖 Iniciando: {nome}")
    print(f"{'='*60}")
    try:
        resultado = subprocess.run(
            [sys.executable, caminho],
            capture_output=False,  # deixa o output aparecer em tempo real
            timeout=600,           # 10 minutos por agente
        )
    except subprocess.TimeoutExpired:
        print(f"\n⏱️ Timeout: {nome} passou de 10 minutos e foi interrompido.")
        return False
    except Exception as e:
        print(f"\n❌ Erro ao executar {nome}: {e}")
        return False
    return resultado.returncode == 0


# ─── Fluxo principal ──────────────────────────────────────────────────────────

def rodar_pipeline():
    """Executa o pipeline completo: Pesquisador → Redator → SEO → Publicador."""
    inicio = datetime.datetime.now()
    print(f"\n{'#'*60}")
    print(f"  🚀 PIPELINE INICIADO — {inicio.strftime('%d/%m/%Y %H:%M')}")
    print(f"{'#'*60}")

    etapas = [
        ("agente_pesquisador.py", "AGENTE 1 — PESQUISADOR"),
        ("agente_redator.py",     "AGENTE 2 — REDATOR"),
        ("agente_seo.py",         "AGENTE 3 — SEO"),
        ("agente_publicador.py",  "AGENTE 4 — PUBLICADOR"),
    ]

    for script, nome in etapas:
        ok = _rodar_agente(script, nome)
        if not ok:
            print(f"\n❌ Falha em {nome}. Pipeline interrompido.")
            _registrar_resultado("FALHA", nome, inicio)
            return False

    fim = datetime.datetime.now()
    duracao = (fim - inicio).seconds
    print(f"\n{'#'*60}")
    print(f"  ✅ PIPELINE CONCLUÍDO em {duracao//60}m {duracao%60}s")
    print(f"{'#'*60}\n")
    _registrar_resultado("SUCESSO", "pipeline completo", inicio, duracao)
    return True


def rodar_monitor():
    """Roda apenas o monitor."""
    return _rodar_agente("agente_monitor.py", "AGENTE 5 — MONITOR")


def _registrar_resultado(status: str, etapa: str, inicio: datetime.datetime, duracao_s: int = 0):
    log = {
        "ts": datetime.datetime.now().isoformat(),
        "status": status,
        "etapa": etapa,
        "duracao_s": duracao_s,
    }
    with open(os.path.join(PASTA, "log_pipeline.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(log, ensure_ascii=False) + "\n")


# ─── Agendamento via Windows Task Scheduler ───────────────────────────────────

def agendar_windows():
    """Cria duas tarefas no Agendador do Windows."""
    python = sys.executable
    pipeline = os.path.abspath(__file__)

    tarefas = [
        {
            "nome": "LucasSemim_Pipeline",
            "horario": HORA_PUBLICACAO,
            "args": "",
            "descricao": "Pipeline diário de artigos (pesquisa → redação → SEO → publicação)",
        },
        {
            "nome": "LucasSemim_Monitor",
            "horario": HORA_MONITOR,
            "args": "--monitor",
            "descricao": "Monitor de saúde do site lucassemim.adv.br",
        },
    ]

    for t in tarefas:
        cmd = (
            f'schtasks /Create /F /SC DAILY /TN "{t["nome"]}" '
            f'/ST {t["horario"]} '
            f'/TR "\\"{python}\\" \\"{pipeline}\\" {t["args"]}" '
            f'/RU {os.environ.get("USERNAME", "adm")} '
            f'/RL HIGHEST'
        )
        resultado = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if resultado.returncode == 0:
            print(f"  ✅ Tarefa criada: {t['nome']} — todos os dias às {t['horario']}")
        else:
            print(f"  ❌ Falha ao criar {t['nome']}: {resultado.stderr}")

    print("\n📋 Verifique no Agendador de Tarefas do Windows (taskschd.msc)")


# ─── Entry point ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Pipeline de agentes — lucassemim.adv.br")
    parser.add_argument("--agendar", action="store_true", help="Agenda execução diária no Windows")
    parser.add_argument("--monitor", action="store_true", help="Roda só o monitor")
    parser.add_argument("--testar", action="store_true", help="Testa conexões sem publicar")
    parser.add_argument("--retroalimentar", action="store_true", help="Executa o motor de auto retro-alimentação contínua")
    args = parser.parse_args()

    if args.testar:
        print("[TESTE] Testando conexoes...")
        _testar_omni()
        _testar_ftp()
        return

    if args.retroalimentar:
        print("[RETROALIMENTAR] Executando motor de auto retro-alimentação...")
        from motor_retroalimentacao import executar_ciclo_retroalimentacao
        executar_ciclo_retroalimentacao()
        return

    if args.agendar:
        print("[AGENDAR] Agendando tarefas no Windows...")
        agendar_windows()
        return

    if args.monitor:
        rodar_monitor()
        return

    rodar_pipeline()


if __name__ == "__main__":
    main()
