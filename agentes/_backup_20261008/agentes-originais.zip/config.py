import os
import datetime
import urllib.request
import json
import time

OMNI_BASE = "http://localhost:20128/api/v1"

# Credenciais FTP decodificadas
FTP_HOST = "ftp.lucassemim.adv.br"
FTP_PORT = 21
FTP_USER = "lucassemim1"
FTP_PASS = "<SENHA-REMOVIDA-EM-20261008>"
FTP_ROOT = "/public_html"
FTP_CIVEL = "/public_html/civel"

# Caminhos locais
SITE_DIR = r"C:\Users\adm\Desktop\lucassemim.adv.br"
CIVEL_DIR = os.path.join(SITE_DIR, "civel")

# Agendamentos (usados pelo agendar.py / task scheduler)
HORA_PUBLICACAO = "03:00"
HORA_MONITOR = "06:00"

def encontrar_modelo_funcionando(timeout=10):
    cache = os.path.join(os.path.dirname(__file__), 'working_model.txt')
    if os.path.exists(cache) and (time.time() - os.path.getmtime(cache) < 3600):
        with open(cache, 'r') as f: return f.read().strip()
    
    # Priorizando os modelos ativados do Gemini (Google AI Studio) na nossa configuração
    candidatos = [
        'antigravity/gemini-3.5-flash-high',
        'antigravity/gemini-3.1-pro-high',
        'auto/gemini',
        'gemini/gemini-1.5-pro',
        'gemini/gemini-1.5-flash',
        'gweb/gemini-3.5-flash'
    ]
    
    payload = json.dumps({'model': 'X', 'messages': [{'role':'user','content':'ok'}], 'stream': False, 'max_tokens': 5}).encode()
    for m in candidatos:
        try:
            p = payload.replace(b'"X"', f'"{m}"'.encode())
            req = urllib.request.Request(f'{OMNI_BASE}/chat/completions', data=p, headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(req, timeout=timeout) as r:
                if r.status == 200:
                    with open(cache, 'w') as f: f.write(m)
                    return m
        except Exception as e:
            pass
    return "antigravity/gemini-3.5-flash-high" # Fallback

MODELO_ATIVO = encontrar_modelo_funcionando()

# Todos os agentes usam o Gemini ativado
MODELOS = {
    "pesquisador": MODELO_ATIVO,
    "redator": MODELO_ATIVO,
    "seo": MODELO_ATIVO,
    "publicador": MODELO_ATIVO,
    "monitor": MODELO_ATIVO,
}

SOBRE_O_SITE = """
Dr. Lucas Renan Semim é um advogado criminalista com atuação combativa em Belo Horizonte, Sabará e região.
Inscrição OAB/MG: 222.539.
Foco principal: defesas urgentes (flagrante, habeas corpus, Maria da Penha, júri popular, tráfico de drogas).
Tom de voz: técnico, mas com empatia, foco total em urgência e soluções rápidas para familiares desesperados.
Sempre inclua referências à atuação estratégica na delegacia e no tribunal.
"""
