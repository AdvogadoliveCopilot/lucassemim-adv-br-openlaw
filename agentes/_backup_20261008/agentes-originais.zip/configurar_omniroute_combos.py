r"""
Configurador e Sincronizador de Combos do OmniRoute.
Registra os combos principais e de fallback no banco SQLite do OmniRoute.
"""

import sqlite3
import json
import uuid
import datetime
import os

DB_PATH = os.path.expanduser(r"~\.omniroute\storage.sqlite")

COMBOS_DEFINITION = [
    {
        "id": "combo-best-fast",
        "name": "auto/best-fast",
        "strategy": "priority",
        "models": [
            {"model": "gemini-2.0-flash", "providerId": "gemini", "weight": 100},
            {"model": "cc/claude-sonnet-4-6", "providerId": "claude", "weight": 90},
            {"model": "ddgw/gpt-4o-mini", "providerId": "ddgw", "weight": 80},
            {"model": "gweb/gemini-3.5-flash", "providerId": "gweb", "weight": 70},
            {"model": "tllm/gemini_2_0_flash", "providerId": "tllm", "weight": 60},
        ],
        "description": "Combo ultra-rapido para pesquisa de pautas, SEO e monitoramento.",
    },
    {
        "id": "combo-pro-chat",
        "name": "auto/pro-chat",
        "strategy": "priority",
        "models": [
            {"model": "gemini-1.5-pro", "providerId": "gemini", "weight": 100},
            {"model": "gemini-2.0-flash", "providerId": "gemini", "weight": 90},
            {"model": "cc/claude-sonnet-4-6", "providerId": "claude", "weight": 85},
            {"model": "ddgw/gpt-4o-mini", "providerId": "ddgw", "weight": 70},
            {"model": "oc/deepseek-v4-flash-free", "providerId": "opencode", "weight": 60},
        ],
        "description": "Combo profissional para redacao aprofundada de artigos juridicos.",
    },
    {
        "id": "combo-smart",
        "name": "auto/smart",
        "strategy": "priority",
        "models": [
            {"model": "gemini-2.0-flash", "providerId": "gemini", "weight": 100},
            {"model": "gemini-1.5-pro", "providerId": "gemini", "weight": 90},
            {"model": "cc/claude-sonnet-4-6", "providerId": "claude", "weight": 80},
            {"model": "ddgw/gpt-4o-mini", "providerId": "ddgw", "weight": 70},
        ],
        "description": "Combo inteligente balanceado para auditoria SEO e refinamento.",
    },
    {
        "id": "combo-coding",
        "name": "auto/coding",
        "strategy": "priority",
        "models": [
            {"model": "gemini-2.0-flash", "providerId": "gemini", "weight": 100},
            {"model": "cc/claude-sonnet-4-6", "providerId": "claude", "weight": 90},
            {"model": "ddgw/gpt-4o-mini", "providerId": "ddgw", "weight": 75},
        ],
        "description": "Combo tecnico para automacao de codigo HTML e publicacoes FTP.",
    },
    {
        "id": "combo-legal-writer",
        "name": "auto/legal-writer",
        "strategy": "priority",
        "models": [
            {"model": "gemini-1.5-pro", "providerId": "gemini", "weight": 100},
            {"model": "gemini-2.0-flash", "providerId": "gemini", "weight": 90},
            {"model": "cc/claude-sonnet-4-6", "providerId": "claude", "weight": 80},
        ],
        "description": "Combo especializado em Direito Penal, Juri, Trafico e Audiencia de Custodia.",
    },
    {
        "id": "combo-free",
        "name": "auto/free",
        "strategy": "priority",
        "models": [
            {"model": "ddgw/gpt-4o-mini", "providerId": "ddgw", "weight": 100},
            {"model": "ddgw/llama-4-scout", "providerId": "ddgw", "weight": 90},
            {"model": "oc/deepseek-v4-flash-free", "providerId": "opencode", "weight": 80},
            {"model": "gweb/gemini-3.1-flash-lite", "providerId": "gweb", "weight": 70},
        ],
        "description": "Combo gratuito com fallbacks comunitarios.",
    },
]


def configurar_combos():
    if not os.path.exists(DB_PATH):
        print(f"Banco do OmniRoute nao encontrado em: {DB_PATH}")
        return False

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()

    print(f"Conectado ao banco: {DB_PATH}")
    print("Configurando combos no OmniRoute...")

    for idx, c in enumerate(COMBOS_DEFINITION, start=1):
        combo_id = c["id"]
        combo_name = c["name"]
        sort_order = idx

        # Normaliza steps dos modelos
        steps = []
        for s_idx, m in enumerate(c["models"]):
            step_id = f"{c['id']}-model-{s_idx+1}-{m['model'].replace('/', '-')}"
            steps.append({
                "id": step_id,
                "kind": "model",
                "model": m["model"],
                "providerId": m.get("providerId"),
                "weight": m.get("weight", 100),
            })

        data_blob = {
            "id": combo_id,
            "name": combo_name,
            "strategy": c["strategy"],
            "models": steps,
            "config": {"description": c["description"]},
            "isHidden": False,
            "sortOrder": sort_order,
            "version": 2,
            "createdAt": now,
            "updatedAt": now,
        }

        # Verifica se ja existe
        cursor.execute("SELECT id FROM combos WHERE name = ?", (combo_name,))
        row = cursor.fetchone()

        if row:
            cursor.execute(
                "UPDATE combos SET data = ?, sort_order = ?, updated_at = ? WHERE name = ?",
                (json.dumps(data_blob), sort_order, now, combo_name),
            )
            print(f"  Atualizado combo: {combo_name} ({len(steps)} modelos encadeados)")
        else:
            cursor.execute(
                "INSERT INTO combos (id, name, data, sort_order, created_at, updated_at, context_cache_protection) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (combo_id, combo_name, json.dumps(data_blob), sort_order, now, now, 0),
            )
            print(f"  Criado novo combo: {combo_name} ({len(steps)} modelos encadeados)")

    conn.commit()
    conn.close()
    print("Todos os combos foram registrados e salvos no OmniRoute com sucesso!\n")
    return True


if __name__ == "__main__":
    configurar_combos()
