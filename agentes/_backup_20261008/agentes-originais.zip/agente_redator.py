﻿"""
AGENTE 2 — REDATOR
Lê o briefing do Pesquisador e gera o HTML completo no padrão do site.
Usa o OmniRoute (auto/pro-chat) para qualidade máxima de escrita.
"""
import json, datetime, sys, os, re
sys.path.insert(0, os.path.dirname(__file__))
from config import OMNI_BASE, MODELOS, SOBRE_O_SITE
import urllib.request
import time
import urllib.error

def _omni_chat(prompt: str, model: str | None = None) -> str:
    """Faz a chamada ao OmniRoute com sistema anti-bloqueio (Retry/Backoff para Erro 429)."""
    model = model or MODELOS[os.path.basename(__file__).split('_')[1].split('.')[0]]
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    
    tentativas = 5
    espera = 10  # segundos
    
    for i in range(tentativas):
        try:
            req = urllib.request.Request(
                f"{OMNI_BASE}/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f"    ⏳ [Limite de velocidade atingido] Aguardando {espera}s para tentar de novo...")
                time.sleep(espera)
                espera += 10 # Aumenta a espera
            else:
                raise e
    raise Exception("Falha após várias tentativas de contato com a IA (Erro 429 contínuo).")



# Template base — adapte ao padrão real do site
TEMPLATE_ARTIGO = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{titulo} | Dr. Lucas Semim OAB/MG 222.539</title>
    <meta name="description" content="{meta_description}">
    <link rel="canonical" href="https://lucassemim.adv.br/{pasta}/{slug}.html" />
    <link rel="icon" href="/img/Favicon-lucassemim.png" type="image/png">
    {schema}
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Teko:wght@300;400;500;600&family=Fira+Code:wght@400;500&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --bg-zero:#000000; --bg-deep:#040404; --bg-card:#080808; --ouro:#d4af37; --ouro-vivo:#f1c40f; --ouro-dim:rgba(212, 175, 55, 0.12); --ouro-border:rgba(212, 175, 55, 0.25); --alerta:#cc0000; --font-display:'Playfair Display', serif; --font-teko:'Teko', sans-serif; --font-body:'Lato', sans-serif; }
        body { background-color: var(--bg-zero); color: #f0ede8; font-family: var(--font-body); padding-top: 110px; }
        h1, h2, h3 { font-family: var(--font-display); font-weight: 700; }
        .faixa-custodia-urgente { background: var(--alerta); padding: 9px 0; position: fixed; top: 0; left: 0; width: 100%; z-index: 10000; text-align:center;}
        .faixa-txt { font-family: 'Fira Code', monospace; font-size: 0.75rem; color: #fff; letter-spacing: 1.5px; text-transform: uppercase; }
        .hero-title { font-family: var(--font-teko); font-size: clamp(3rem, 6vw, 5rem); color: #fff; text-transform: uppercase; line-height: 0.9; margin: 30px 0; }
        .ouro-line { background: linear-gradient(90deg, var(--ouro), var(--ouro-vivo)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .artigo-conteudo { max-width: 900px; margin: 0 auto; padding: 40px 20px; font-size: 1.15rem; line-height: 1.8; color:#d8d4c9; }
        .artigo-conteudo h2 { color: var(--ouro-vivo); margin-top: 40px; }
        .btn-acionar { display: inline-flex; align-items: center; gap: 12px; background: linear-gradient(135deg, #cc0000, #8b0000); color: #fff; font-family: var(--font-teko); font-size: 1.5rem; letter-spacing: 1.5px; padding: 16px 32px; border-radius: 8px; text-decoration:none;}
        #header-master-injecao { position: fixed; top: 38px; width: 100%; z-index: 9999;}
    </style>
</head>
<body>
    <div class="faixa-custodia-urgente"><span class="faixa-txt">PLANTÃO 24H CRIMINAL - LIGUE AGORA: (31) 98394-4973</span></div>
    <div id="header-master-injecao"></div>

    <section class="container" style="margin-top:40px; text-align:center;">
        <h1 class="hero-title">{titulo}</h1>
        <p style="color:#888; font-style:italic;">Por Dr. Lucas Semim</p>
    </section>

    <main class="artigo-conteudo">
        {conteudo_html}
        
        <div style="margin-top:60px; text-align:center;">
            <a href="https://wa.me/5531983944973?text=Ol%C3%A1%2C%20Dr.%20Lucas.%20Preciso%20de%20ajuda%20urgente." class="btn-acionar">
                <i class="fab fa-whatsapp"></i> FALAR COM DR. LUCAS AGORA
            </a>
        </div>
    </main>

    <div id="footer-master-injecao"></div>
    <script src="/js/header-elite.js?v={versao}"></script>
</body>
</html>"""





def _slug(titulo: str) -> str:
    """Gera slug a partir do título."""
    s = titulo.lower()
    s = re.sub(r'[áàãâä]', 'a', s)
    s = re.sub(r'[éèêë]', 'e', s)
    s = re.sub(r'[íìîï]', 'i', s)
    s = re.sub(r'[óòõôö]', 'o', s)
    s = re.sub(r'[úùûü]', 'u', s)
    s = re.sub(r'ç', 'c', s)
    s = re.sub(r'[^a-z0-9\s-]', '', s)
    s = re.sub(r'\s+', '-', s.strip())
    return s[:80]


def _tempo_leitura(html: str) -> int:
    """Estima tempo de leitura em minutos (200 palavras/min)."""
    texto = re.sub(r'<[^>]+>', '', html)
    palavras = len(texto.split())
    return max(1, round(palavras / 200))


def redigir_artigo(pauta: dict, briefing: str) -> dict:
    """
    Redige o artigo completo.
    Retorna dict com: html, titulo, slug, meta_description, tags, categoria
    """
    prompt = f"""Você é o ghostwriter do Dr. Lucas Renan Semim, advogado criminalista.

CONTEXTO DO SITE:
{SOBRE_O_SITE}

PAUTA:
Título sugerido: {pauta['titulo']}
Palavras-chave: {', '.join(pauta['palavras_chave'])}
Tipo: {'artigo urgente (curto e direto, 400-600 palavras)' if pauta['urgente'] else 'artigo explicativo (completo, 800-1200 palavras)'}

BRIEFING DO PESQUISADOR:
{briefing}

TAREFA:
Redija o artigo COMPLETO em HTML semântico. Use:
- <h2> para seções principais (mínimo 3)
- <h3> para subseções quando necessário
- <p> para parágrafos
- <ul>/<li> para listas
- <strong> para termos importantes
- <blockquote> para citações de lei ou jurisprudência (com <cite>)
- classe "destaque-cta" em um parágrafo que mencione o Dr. Lucas sutilmente

NÃO inclua <html>, <head>, <body> — apenas o conteúdo interno.
A primeira frase deve ser poderosa e direta ao problema do leitor.
Termine com um parágrafo de conclusão que convide a contatar o Dr. Lucas.

Responda em JSON:
{{
  "conteudo_html": "...",
  "meta_description": "...(máx 155 chars)",
  "titulo_final": "...",
  "categoria": "Flagrante|Preventiva|Habeas Corpus|Maria da Penha|Tráfico|Outros",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}}"""

    resposta = _omni_chat(prompt)
    resposta = resposta.strip()
    if resposta.startswith("```"):
        resposta = resposta.split("```")[1]
        if resposta.startswith("json"):
            resposta = resposta[4:]

    dados = json.loads(resposta.strip())

    # Monta o HTML final
    hoje = datetime.date.today()
    versao = hoje.strftime("%Y%m%d")
    slug_val = _slug(dados["titulo_final"])
    tags_html = " ".join(f'<a href="/artigos.html?tag={t.replace(" ","-")}" class="tag">{t}</a>'
                         for t in dados["tags"])

    # Schema Article
    schema = f"""<script type="application/ld+json">
{{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "{dados['titulo_final']}",
  "author": {{"@type": "Person", "name": "Dr. Lucas Renan Semim"}},
  "datePublished": "{hoje.isoformat()}",
  "description": "{dados['meta_description']}"
}}
</script>"""

    html_completo = TEMPLATE_ARTIGO.format(
        titulo=dados["titulo_final"],
        meta_description=dados["meta_description"],
        slug=slug_val,
        versao=versao,
        schema=schema,
        categoria=dados["categoria"],
        data_iso=hoje.isoformat(),
        data_formatada=hoje.strftime("%d de %B de %Y"),
        tempo_leitura=_tempo_leitura(dados["conteudo_html"]),
        conteudo_html=dados["conteudo_html"],
        tags_html=tags_html,
    )

    return {
        "html": html_completo,
        "titulo": dados["titulo_final"],
        "slug": slug_val,
        "meta_description": dados["meta_description"],
        "tags": dados["tags"],
        "categoria": dados["categoria"],
        "nome_arquivo": f"{slug_val}.html",
    }


if __name__ == "__main__":
    entrada = os.path.join(os.path.dirname(__file__), "output_pesquisador.json")
    if not os.path.exists(entrada):
        print("❌ Execute o agente_pesquisador.py primeiro.")
        sys.exit(1)

    with open(entrada, encoding="utf-8") as f:
        dados = json.load(f)

    pautas = dados["pautas"]
    briefings = dados["briefings"]

    artigos = []
    for i, (pauta, briefing) in enumerate(zip(pautas[:1], briefings)):  # começa com 1
        print(f"✍️  Redigindo artigo {i+1}: {pauta['titulo']}...")
        artigo = redigir_artigo(pauta, briefing)
        artigos.append(artigo)
        print(f"  ✅ {artigo['nome_arquivo']} ({len(artigo['html'])} bytes)")

    with open(os.path.join(os.path.dirname(__file__), "output_redator.json"), "w", encoding="utf-8") as f:
        json.dump({"data": dados["data"], "artigos": artigos}, f, ensure_ascii=False, indent=2)
    print("\n💾 Salvo em output_redator.json")

