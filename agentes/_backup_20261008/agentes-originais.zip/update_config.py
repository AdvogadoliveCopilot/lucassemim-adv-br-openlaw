import re

ARQUIVO = r'C:\Users\adm\Desktop\lucassemim.adv.br\agentes\config.py'

with open(ARQUIVO, 'r', encoding='utf-8') as f:
    text = f.read()

# Substituir o bloco da função encontrar_modelo_funcionando inteira
nova_funcao = '''def encontrar_modelo_funcionando(timeout=10):
    import urllib.request, json, os, time
    cache = os.path.join(os.path.dirname(__file__), 'working_model.txt')
    if os.path.exists(cache) and (time.time() - os.path.getmtime(cache) < 3600):
        with open(cache, 'r') as f: return f.read().strip()
    
    # Priorizando os modelos ativados do Gemini (Google AI Studio)
    candidatos = [
        'antigravity/gemini-3.5-flash-high',
        'antigravity/gemini-3.1-pro-high',
        'auto/gemini',
        'gemini/gemini-1.5-pro',
        'gemini/gemini-1.5-flash',
        'gweb/gemini-3.5-flash'
    ]
    
    payload = json.dumps({'model': 'X', 'messages': [{'role':'user','content':'ok'}], 'stream': False, 'max_tokens': 5}).encode()
    for m in candidatos:
        try:
            p = payload.replace(b'"X"', f'"{m}"'.encode())
            req = urllib.request.Request(f'{OMNI_BASE}/chat/completions', data=p, headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(req, timeout=timeout) as r:
                if r.status == 200:
                    with open(cache, 'w') as f: f.write(m)
                    return m
        except Exception as e:
            pass
    return "antigravity/gemini-3.5-flash-high" # Fallback padrão se não testar
'''

text = re.sub(r'def encontrar_modelo_funcionando.*?return None\n', nova_funcao, text, flags=re.DOTALL)

# Configurar todos os modelos para usar o que estiver ativo
sub_modelos = '''
MODELO_ATIVO = encontrar_modelo_funcionando()

MODELOS = {
    "pesquisador": MODELO_ATIVO,
    "redator": MODELO_ATIVO,
    "seo": MODELO_ATIVO,
    "publicador": MODELO_ATIVO,
    "monitor": MODELO_ATIVO,
}
'''
if 'MODELOS = {' in text:
    text = re.sub(r'MODELOS = \{.*?\n}', sub_modelos, text, flags=re.DOTALL)
else:
    text += "\n" + sub_modelos

with open(ARQUIVO, 'w', encoding='utf-8') as f:
    f.write(text)

print('config.py atualizado com sucesso!')
